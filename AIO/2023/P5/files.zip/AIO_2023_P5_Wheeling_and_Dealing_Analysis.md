# AIO 2023 — Problem 5: Wheeling and Dealing

**Solution Analysis & Teaching Notes**

---

## 1. Problem Restatement

There are `N` candidates and `M` voters. Voter `i` plans to vote for candidate `Vi`, and can be paid `Pi` dollars to vote for **any candidate of your choosing**. Candidate 1 wins only by getting **strictly more** votes than every other candidate. Find the minimum total payment so that candidate 1 wins.

Constraints: `N, M ≤ 100,000`, `0 ≤ Pi ≤ 10,000`. Time limit 1 second.

---

## 2. First Observations

**Observation 1 — never pay candidate 1's own voters.** They're already voting the right way; paying them gains nothing.

**Observation 2 — every voter you buy should be redirected to candidate 1.** Suppose you've decided *which* set `S` of voters to buy. Sending all of them to candidate 1 maximises candidate 1's total and gives every rival their minimum possible total. Redirecting a bought voter to some other candidate can only raise a rival's count, never lower one. So for any fixed set `S`, "all to candidate 1" is at least as good as any other redirection.

> The sample explanation redirects a voter to candidate 2 — that's also valid, but never *better*. This observation collapses the redirection choice entirely: the problem reduces to choosing **which voters to buy**.

**Observation 3 — the answer is determined by a single parameter.** If candidate 1 finishes with `k` votes, then winning means every rival finishes with **at most `k − 1`** votes. This suggests the classic technique: **enumerate `k`**, compute the cheapest way to achieve "candidate 1 has ≥ k, everyone else has ≤ k − 1", and take the minimum over all `k`.

Why must we try every `k`? Because the cost is **not monotonic or unimodal in `k`**. A small `k` forces you to buy down every big rival; a large `k` forces you to buy lots of top-up votes. The optimum sits somewhere in between, and there is no reliable way to binary-search for it. Checking all `k ∈ {1, …, M}` is safe and, as we'll see, cheap.

---

## 3. Solving for a Fixed k

With `k` fixed, the greedy structure is clean. Let `c1` be candidate 1's initial vote count and `cnt_j` the count for rival `j`.

**Step A — forced buys.** Any rival `j` with `cnt_j ≥ k` must lose voters until it has `k − 1` left, i.e. you must buy exactly `cnt_j − k + 1` of its voters. Since you only care about *how many* leave, buy the **cheapest** ones. (Exchange argument: swapping a bought expensive voter for an unbought cheaper voter of the same candidate keeps the count valid and never raises the cost.)

**Step B — top-up buys.** All forced voters now vote for candidate 1 (Observation 2). If `c1 + forced ≥ k`, you're done — candidate 1 strictly beats everyone. Otherwise buy the cheapest `k − c1 − forced` voters from the remaining (un-forced) pool of rival voters; each one simultaneously adds to candidate 1 and subtracts from a rival, so it can never break the `≤ k − 1` constraint.

```
cost(k) = (cheapest forced voters per oversized rival)
        + (cheapest top-up voters from everyone left over)
answer  = min over k of cost(k)
```

**Worked check — Sample 1** (`c1 = 1`; rival counts: cand 3 → {4, 7}, cand 4 → {1, 9}, cand 5 → {8}):

| k | Forced | Top-up needed | Cost |
|---|--------|---------------|------|
| 3 | none | 2 → buy {1, 4} | **5** |
| 2 | cand 3 buys {4}, cand 4 buys {1} | 0 (1 + 2 ≥ 2) | **5** |
| 1 | all five rival voters | 0 | 29 |

Minimum = 5 ✓. Sample 2 gives its minimum 6 at `k = 3` (buy the three cheapest of {1,2,3,4,6}), and Sample 3 gives 0 at `k = 2` ✓.

---

## 4. Subtask Progression

**Subtask 1 (15 marks, N, M ≤ 1000, all Pi = 1).** Cost = number of voters bought. For each `k`, `cost(k) = Σ_j max(0, cnt_j − k + 1) + max(0, k − c1 − forced)`. Computing this naively per `k` is `O(N)` and there are `O(M)` values of `k`: comfortably fast at these sizes.

**Subtask 2 (15 marks, all Pi = 1, full sizes).** Same formula, but `O(NM)` is now too slow. Precompute `ge[c]` = number of rivals with count ≥ c and `sumge[c]` = sum of those counts using suffix sums over a count-of-counts array. Then each `cost(k)` is O(1): forced = `sumge[k] − ge[k]·(k−1)`. Total `O(N + M)`.

**Subtask 3 (40 marks, N, M ≤ 100).** Prices now matter, but sizes are tiny. For each `k`, run the two greedy steps directly: sort each rival's voters once up front, take prefixes for forced buys, then sort the leftover pool for top-ups. Roughly `O(M² log M)` — trivially fast. *This subtask is the conceptual heart of the problem; the remaining 30 marks are pure data structures.*

**Subtask 4 (30 marks, full constraints).** We need all `M` values of `k` efficiently. Two costs to handle:

*Forced buys are cheap in aggregate.* Sweep `k` from `M` down to `1`. A rival with `cnt_j` voters becomes "active" when `k` reaches `cnt_j`, and forfeits exactly one more cheapest voter (a pointer into its pre-sorted list) for each further decrement of `k`. Across the whole sweep the total number of forfeit operations is `Σ cnt_j ≤ M` — amortised `O(M)`. Maintain running totals `forcedSum` and `forcedCnt`.

*Top-ups need a "sum of x cheapest" query.* The optional pool shrinks as voters become forced, and the needed count `x = k − c1 − forcedCnt` jumps around non-monotonically, so a simple pointer won't do. Exploit `Pi ≤ 10,000`: keep a **Fenwick tree indexed by cost value**, where node `i` stores the *count* and *dollar sum* of optional voters with that cost. A binary-search descent down the tree finds the largest prefix holding fewer than `x` voters, then charges the remainder at the boundary cost — `O(log Pmax)` per query. (A balanced BST / order-statistics tree indexed by sorted voter position works equally well if prices were unbounded.)

**Total: `O(M log M)` sorting + `O(M log Pmax)` sweep.** Runs in ~25 ms in C++ and well under a second even in Python.

---

## 5. Common Pitfalls

1. **Trying to binary-search on `k`.** `cost(k)` is not unimodal in general; you must evaluate every `k`.
2. **Forgetting the top-up can be zero or negative.** When forced buys alone push candidate 1 past `k`, the top-up term is `max(0, ·)` — over-buying is fine because the extras still go to candidate 1.
3. **Buying a rival's expensive voter "because it also tops up candidate 1".** It doesn't help: any voter you buy counts toward both goals, so cheapest-first within each step is always optimal.
4. **Per-`k` recomputation from scratch.** `O(M)` work per `k` is `O(M²)` overall — fine for Subtask 3, a timeout on Subtask 4. The sweep must be amortised.
5. **`Pi = 0` voters.** Costs start at 0, so the Fenwick index must be `cost + 1` (1-indexed trees can't take index 0).
6. **Overflow.** Max cost ≈ `10⁵ × 10⁴ = 10⁹` — fits in 32 bits with no room to spare; use 64-bit accumulators.

---

## 6. Reference Implementations

Both solutions below were stress-tested against an exhaustive brute force (500 random cases each) and pass all samples.

### Python (`solution.py`)

```python
import sys


def main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    votes = data[2:2 + m]
    pays = data[2 + m:2 + 2 * m]

    c1 = 0                      # voters already committed to candidate 1
    cand = {}                   # candidate id -> list of voter prices
    for i in range(m):
        v = int(votes[i])
        p = int(pays[i])
        if v == 1:
            c1 += 1             # never any reason to pay these voters
        else:
            cand.setdefault(v, []).append(p)

    # ---- Fenwick tree over cost values 0..10000 (indices 1..10001) ----
    SZ = 10001
    bit_cnt = [0] * (SZ + 1)    # optional-voter count at each cost
    bit_sum = [0] * (SZ + 1)    # optional-voter dollar sum at each cost

    def update(cost: int, dc: int, ds: int) -> None:
        i = cost + 1
        while i <= SZ:
            bit_cnt[i] += dc
            bit_sum[i] += ds
            i += i & (-i)

    def cheapest_sum(x: int) -> int:
        """Sum of the x cheapest costs currently in the tree
        (assumes the tree holds at least x items)."""
        pos, cnt, s = 0, 0, 0
        pw = 1 << 14            # 16384 >= 10001
        while pw:
            npos = pos + pw
            if npos <= SZ and cnt + bit_cnt[npos] < x:
                pos = npos
                cnt += bit_cnt[pos]
                s += bit_sum[pos]
            pw >>= 1
        # the remaining (x - cnt) items all have cost exactly `pos`
        return s + (x - cnt) * pos

    # starts_at[c] = candidates with exactly c voters; they begin
    # producing forced buys once the sweep reaches k == c.
    starts_at = [[] for _ in range(m + 1)]
    lists = []
    for prices in cand.values():
        prices.sort()
        idx = len(lists)
        lists.append(prices)
        starts_at[len(prices)].append(idx)
        for p in prices:
            update(p, 1, p)     # everything starts as "optional"

    ptr = [0] * len(lists)      # forced voters taken per candidate
    active = []                 # candidates with cnt_j >= current k
    forced_sum = 0
    forced_cnt = 0
    best = None

    for k in range(m, 0, -1):
        active.extend(starts_at[k])
        for idx in active:      # each forfeits one more cheapest voter
            p = lists[idx][ptr[idx]]
            ptr[idx] += 1
            update(p, -1, -p)   # optional pool -> forced
            forced_sum += p
            forced_cnt += 1
        need = k - c1 - forced_cnt
        cost = forced_sum + (cheapest_sum(need) if need > 0 else 0)
        if best is None or cost < best:
            best = cost

    print(best)


main()
```

### C++ (`solution.cpp`)

```cpp
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int SZ = 10001;          // costs 0..10000 map to indices 1..10001
ll bitCnt[SZ + 1], bitSum[SZ + 1];

void update(int cost, ll dc, ll ds) {
    for (int i = cost + 1; i <= SZ; i += i & (-i)) {
        bitCnt[i] += dc;
        bitSum[i] += ds;
    }
}

// Sum of the x cheapest costs currently stored (total count >= x).
ll cheapestSum(ll x) {
    if (x <= 0) return 0;
    int pos = 0;
    ll cnt = 0, sum = 0;
    for (int pw = 1 << 14; pw; pw >>= 1) {       // 16384 >= 10001
        int npos = pos + pw;
        if (npos <= SZ && cnt + bitCnt[npos] < x) {
            pos = npos;
            cnt += bitCnt[pos];
            sum += bitSum[pos];
        }
    }
    // remaining (x - cnt) items all cost exactly `pos` dollars
    return sum + (x - cnt) * (ll)pos;
}

int main() {
    int n, m;
    scanf("%d %d", &n, &m);
    vector<int> V(m), P(m);
    for (int i = 0; i < m; i++) scanf("%d", &V[i]);
    for (int i = 0; i < m; i++) scanf("%d", &P[i]);

    int c1 = 0;                                   // candidate 1's own votes
    vector<vector<int>> prices(n + 1);
    for (int i = 0; i < m; i++) {
        if (V[i] == 1) c1++;                      // never pay these voters
        else prices[V[i]].push_back(P[i]);
    }

    // startsAt[c] = candidates with exactly c voters; forced buys begin
    // once the sweep reaches k == c.
    vector<vector<int>> startsAt(m + 1);
    for (int j = 2; j <= n; j++) {
        if (prices[j].empty()) continue;
        sort(prices[j].begin(), prices[j].end());
        startsAt[prices[j].size()].push_back(j);
        for (int p : prices[j]) update(p, 1, p);  // all start "optional"
    }

    vector<int> ptr(n + 1, 0);
    vector<int> active;
    ll forcedSum = 0, forcedCnt = 0;
    ll best = LLONG_MAX;

    for (int k = m; k >= 1; k--) {
        for (int j : startsAt[k]) active.push_back(j);
        for (int j : active) {                    // forfeit one more voter each
            int p = prices[j][ptr[j]++];
            update(p, -1, -p);
            forcedSum += p;
            forcedCnt++;
        }
        ll need = (ll)k - c1 - forcedCnt;
        best = min(best, forcedSum + cheapestSum(need));
    }

    printf("%lld\n", best);
    return 0;
}
```

---

## 7. Summary

| Aspect | Detail |
|--------|--------|
| Technique | Enumerate the answer's structure (final vote count `k`) + two-phase greedy + Fenwick tree on values |
| Key insight | All bought voters go to candidate 1; the problem is purely *which voters to buy*, parameterised by `k` |
| Complexity | `O(M log M + M log Pmax)` time, `O(M + Pmax)` memory |
| Difficulty driver | Subtask 3 tests the greedy idea; Subtask 4 tests amortised sweeping + "sum of x cheapest" queries |
