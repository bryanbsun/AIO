// AIO 2023 Problem 5 - Wheeling and Dealing
// Full solution: O(M log Pmax) after O(M log M) sorting.
//
// Strategy: enumerate k = candidate 1's final vote count.
//   * Every other candidate must finish with <= k-1 votes, so any
//     candidate j with cnt_j >= k is FORCED to lose its cheapest
//     (cnt_j - k + 1) voters. All bought voters go to candidate 1.
//   * If candidate 1 is still short of k votes, TOP UP with the
//     cheapest remaining voters of other candidates.
//   * Answer = min over k of forced cost + top-up cost.
//
// We sweep k from M down to 1. Each time k decreases, each "active"
// candidate (one with cnt_j >= k) forfeits one more cheapest voter;
// the total number of forced operations across the sweep is
// sum(cnt_j) <= M. The top-up query ("sum of the x cheapest optional
// voters") is answered by a Fenwick tree indexed by cost value
// (0..10000) storing counts and sums, using a binary-search descent.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int SZ = 10001;          // costs 0..10000 map to indices 1..10001
ll bitCnt[SZ + 1], bitSum[SZ + 1];

void update(int cost, ll dc, ll ds) {
    for (int i = cost + 1; i <= SZ; i += i & (-i)) {
        bitCnt[i] += dc;
        bitSum[i] += ds;
    }
}

// Sum of the x cheapest costs currently stored (requires total count >= x).
ll cheapestSum(ll x) {
    if (x <= 0) return 0;
    int pos = 0;
    ll cnt = 0, sum = 0;
    for (int pw = 1 << 14; pw; pw >>= 1) {       // 16384 >= 10001
        int npos = pos + pw;
        if (npos <= SZ && cnt + bitCnt[npos] < x) {
            pos = npos;
            cnt += bitCnt[pos];
            sum += bitSum[pos];
        }
    }
    // The remaining (x - cnt) items all live in bucket pos+1,
    // i.e. they all cost exactly `pos` dollars.
    return sum + (x - cnt) * (ll)pos;
}

int main() {
    int n, m;
    scanf("%d %d", &n, &m);
    vector<int> V(m), P(m);
    for (int i = 0; i < m; i++) scanf("%d", &V[i]);
    for (int i = 0; i < m; i++) scanf("%d", &P[i]);

    int c1 = 0;                                   // votes candidate 1 already has
    vector<vector<int>> prices(n + 1);            // prices[j] = costs of j's voters
    for (int i = 0; i < m; i++) {
        if (V[i] == 1) c1++;                      // never worth paying these voters
        else prices[V[i]].push_back(P[i]);
    }

    // startsAt[c] = candidates with exactly c voters; they begin forced
    // buys once the sweep reaches k == c.
    vector<vector<int>> startsAt(m + 1);
    for (int j = 2; j <= n; j++) {
        if (prices[j].empty()) continue;
        sort(prices[j].begin(), prices[j].end());
        startsAt[prices[j].size()].push_back(j);
        for (int p : prices[j]) update(p, 1, p);  // all start as "optional"
    }

    vector<int> ptr(n + 1, 0);                    // forced voters taken from j so far
    vector<int> active;                           // candidates with cnt_j >= current k
    ll forcedSum = 0, forcedCnt = 0;
    ll best = LLONG_MAX;

    for (int k = m; k >= 1; k--) {
        for (int j : startsAt[k]) active.push_back(j);
        for (int j : active) {                    // each forfeits one more cheapest voter
            int p = prices[j][ptr[j]++];
            update(p, -1, -p);                    // optional pool -> forced
            forcedSum += p;
            forcedCnt++;
        }
        ll need = (ll)k - c1 - forcedCnt;         // top candidate 1 up to k votes
        ll cost = forcedSum + cheapestSum(need);
        best = min(best, cost);
    }

    printf("%lld\n", best);
    return 0;
}
