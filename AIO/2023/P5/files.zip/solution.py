"""
AIO 2023 Problem 5 - Wheeling and Dealing
Full solution: O(M log Pmax) after O(M log M) sorting.

Core idea:
  Enumerate k = the number of votes candidate 1 finishes with.
  For candidate 1 to win with k votes, every other candidate must end
  with at most k-1 votes.

  For a fixed k:
    1. FORCED buys: every candidate j != 1 with cnt_j >= k must lose
       (cnt_j - k + 1) voters. Buy their cheapest ones. All bought
       voters are redirected to candidate 1 (always safe: it only
       raises candidate 1's total and lowers nobody else's headroom).
    2. TOP-UP buys: if candidate 1 still has fewer than k votes
       (c1 + forced < k), buy the cheapest remaining voters of other
       candidates to make up the difference.

  Answer = min over all k of (forced cost + top-up cost).

Efficiency:
  - Iterate k from M down to 1. A candidate with cnt_j voters starts
    contributing forced buys when k reaches cnt_j, and contributes one
    more cheapest voter per decrement of k. Total forced operations
    over the whole loop is sum(cnt_j) <= M.
  - The "x cheapest remaining voters" query is answered by a Fenwick
    tree indexed by cost value (0..10000), storing (count, sum) per
    cost. A binary-search descent on the tree finds the sum of the x
    cheapest items in O(log Pmax).
"""
import sys


def main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    votes = data[2:2 + m]
    pays = data[2 + m:2 + 2 * m]

    c1 = 0                      # voters already committed to candidate 1
    cand = {}                   # candidate id -> list of voter prices
    for i in range(m):
        v = int(votes[i])
        p = int(pays[i])
        if v == 1:
            c1 += 1             # never any reason to pay these voters
        else:
            cand.setdefault(v, []).append(p)

    # ---- Fenwick tree over cost values 0..10000 (indices 1..10001) ----
    SZ = 10001
    bit_cnt = [0] * (SZ + 1)    # how many optional voters at each cost
    bit_sum = [0] * (SZ + 1)    # total dollars of optional voters at each cost

    def update(cost: int, dc: int, ds: int) -> None:
        i = cost + 1
        while i <= SZ:
            bit_cnt[i] += dc
            bit_sum[i] += ds
            i += i & (-i)

    def cheapest_sum(x: int) -> int:
        """Sum of the x cheapest costs currently in the tree.
        Assumes the tree contains at least x items."""
        pos, cnt, s = 0, 0, 0
        pw = 1 << 14            # 16384 >= 10001
        while pw:
            npos = pos + pw
            if npos <= SZ and cnt + bit_cnt[npos] < x:
                pos = npos
                cnt += bit_cnt[pos]
                s += bit_sum[pos]
            pw >>= 1
        # The remaining (x - cnt) items all sit in bucket pos+1,
        # i.e. they all have cost exactly `pos`.
        return s + (x - cnt) * pos

    # ---- prepare per-candidate sorted price lists ----
    # starts_at[c] = candidates whose vote count equals c; they begin
    # producing forced buys once k drops to c.
    starts_at = [[] for _ in range(m + 1)]
    lists = []
    for prices in cand.values():
        prices.sort()
        idx = len(lists)
        lists.append(prices)
        starts_at[len(prices)].append(idx)
        for p in prices:
            update(p, 1, p)     # everything starts as "optional"

    ptr = [0] * len(lists)      # how many voters of each candidate are forced
    active = []                 # candidates currently producing forced buys
    forced_sum = 0
    forced_cnt = 0
    best = None

    for k in range(m, 0, -1):
        # candidates whose count == k become active at this k
        active.extend(starts_at[k])
        # every active candidate must give up one more (cheapest) voter
        for idx in active:
            p = lists[idx][ptr[idx]]
            ptr[idx] += 1
            update(p, -1, -p)   # move from optional pool to forced
            forced_sum += p
            forced_cnt += 1
        # top up candidate 1 to k votes if forced buys weren't enough
        need = k - c1 - forced_cnt
        cost = forced_sum + (cheapest_sum(need) if need > 0 else 0)
        if best is None or cost < best:
            best = cost

    print(best)


main()
